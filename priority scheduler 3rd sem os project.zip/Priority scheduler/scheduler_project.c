#include <windows.h>
#include <stdio.h>
#include <stdlib.h>

// Button identifiers
#define ID_SUBMIT_BTN 1
#define ID_CALCULATE_BTN 2
#define ID_DELETE_BTN 3

// Process structure definition
typedef struct {
    int pid;   // Process ID
    int bt;    // Burst Time
    int at;    // Arrival Time
    int prio;  // Priority
    int ft;    // Finish Time
    int tat;   // Turnaround Time
    int wt;    // Waiting Time
} Process;

Process p[10]; // Array to store processes
int process_count = 0; // Current number of processes
int max_time = 0; // Maximum time for Gantt chart scaling

// UI elements for metrics
HWND hCompletionTime, hTurnaroundTime, hWaitingTime, hResponseTime;
HWND hThroughput, hAvgWaitingTime, hAvgTurnaroundTime, hAvgResponseTime;
HWND hCPUUtilization, hFairness;

// Function prototypes
LRESULT CALLBACK WindowProcedure(HWND, UINT, WPARAM, LPARAM);
void sort_processes(int n, Process p[n]);
void execute_processes(HWND hwnd, int n, Process p[n]);
void draw_gantt_chart(HWND hwnd, int n, Process p[n]);
void show_process_table(HWND hwnd);
void delete_process(HWND hwnd, int pid);
void update_metrics(HWND hwnd, int n, Process p[n]);

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow) {
    WNDCLASS wc = {0};
    wc.lpfnWndProc = WindowProcedure;
    wc.hInstance = hInstance;
    wc.lpszClassName = "SchedulerWindow";

    if (!RegisterClass(&wc)) {
        MessageBox(NULL, "Window Class Registration Failed!", "Error", MB_ICONERROR);
        return 1;
    }

    HWND hwnd = CreateWindow("SchedulerWindow", "Priority Scheduling Monitor", WS_OVERLAPPEDWINDOW,
                             CW_USEDEFAULT, CW_USEDEFAULT, 800, 800, NULL, NULL, hInstance, NULL);

    if (!hwnd) {
        MessageBox(NULL, "Window Creation Failed!", "Error", MB_ICONERROR);
        return 1;
    }

    ShowWindow(hwnd, nCmdShow);
    UpdateWindow(hwnd);

    MSG msg;
    while (GetMessage(&msg, NULL, 0, 0)) {
        TranslateMessage(&msg);
        DispatchMessage(&msg);
    }

    return msg.wParam;
}

LRESULT CALLBACK WindowProcedure(HWND hwnd, UINT msg, WPARAM wp, LPARAM lp) {
    static HWND hAt, hBt, hPrio, hPidDelete;

    switch (msg) {
    case WM_CREATE:
        // Create UI components for process input
        CreateWindow("STATIC", "Enter Process Data:", WS_VISIBLE | WS_CHILD, 20, 20, 200, 20, hwnd, NULL, NULL, NULL);
        CreateWindow("STATIC", "Arrival Time:", WS_VISIBLE | WS_CHILD, 20, 50, 100, 20, hwnd, NULL, NULL, NULL);
        CreateWindow("STATIC", "Burst Time:", WS_VISIBLE | WS_CHILD, 20, 80, 100, 20, hwnd, NULL, NULL, NULL);
        CreateWindow("STATIC", "Priority:", WS_VISIBLE | WS_CHILD, 20, 110, 100, 20, hwnd, NULL, NULL, NULL);

        hAt = CreateWindow("EDIT", "", WS_VISIBLE | WS_CHILD | WS_BORDER, 120, 50, 100, 20, hwnd, NULL, NULL, NULL);
        hBt = CreateWindow("EDIT", "", WS_VISIBLE | WS_CHILD | WS_BORDER, 120, 80, 100, 20, hwnd, NULL, NULL, NULL);
        hPrio = CreateWindow("EDIT", "", WS_VISIBLE | WS_CHILD | WS_BORDER, 120, 110, 100, 20, hwnd, NULL, NULL, NULL);

        CreateWindow("BUTTON", "Add Process", WS_VISIBLE | WS_CHILD, 120, 140, 100, 30, hwnd, (HMENU)ID_SUBMIT_BTN, NULL, NULL);
        CreateWindow("BUTTON", "Calculate", WS_VISIBLE | WS_CHILD, 240, 140, 100, 30, hwnd, (HMENU)ID_CALCULATE_BTN, NULL, NULL);

        // Create UI components for process deletion
        CreateWindow("STATIC", "Delete Process by PID:", WS_VISIBLE | WS_CHILD, 20, 200, 150, 20, hwnd, NULL, NULL, NULL);
        hPidDelete = CreateWindow("EDIT", "", WS_VISIBLE | WS_CHILD | WS_BORDER, 180, 200, 50, 20, hwnd, NULL, NULL, NULL);
        CreateWindow("BUTTON", "Delete", WS_VISIBLE | WS_CHILD, 240, 200, 100, 30, hwnd, (HMENU)ID_DELETE_BTN, NULL, NULL);

        // Metrics UI
        hCompletionTime = CreateWindow("STATIC", "Completion Time: ", WS_VISIBLE | WS_CHILD, 50, 380, 700, 20, hwnd, NULL, NULL, NULL);
        hTurnaroundTime = CreateWindow("STATIC", "Turnaround Time: ", WS_VISIBLE | WS_CHILD, 50, 410, 700, 20, hwnd, NULL, NULL, NULL);
        hWaitingTime = CreateWindow("STATIC", "Waiting Time: ", WS_VISIBLE | WS_CHILD, 50, 440, 700, 20, hwnd, NULL, NULL, NULL);
        hResponseTime = CreateWindow("STATIC", "Response Time: ", WS_VISIBLE | WS_CHILD, 50, 470, 700, 20, hwnd, NULL, NULL, NULL);
        hThroughput = CreateWindow("STATIC", "Throughput: ", WS_VISIBLE | WS_CHILD, 50, 500, 700, 20, hwnd, NULL, NULL, NULL);
        hAvgWaitingTime = CreateWindow("STATIC", "Average Waiting Time: ", WS_VISIBLE | WS_CHILD, 50, 530, 700, 20, hwnd, NULL, NULL, NULL);
        hAvgTurnaroundTime = CreateWindow("STATIC", "Average Turnaround Time: ", WS_VISIBLE | WS_CHILD, 50, 560, 700, 20, hwnd, NULL, NULL, NULL);
        hAvgResponseTime = CreateWindow("STATIC", "Average Response Time: ", WS_VISIBLE | WS_CHILD, 50, 590, 700, 20, hwnd, NULL, NULL, NULL);
        hCPUUtilization = CreateWindow("STATIC", "CPU Utilization: ", WS_VISIBLE | WS_CHILD, 50, 620, 700, 20, hwnd, NULL, NULL, NULL);
        hFairness = CreateWindow("STATIC", "Fairness: ", WS_VISIBLE | WS_CHILD, 50, 650, 700, 20, hwnd, NULL, NULL, NULL);
        break;

    case WM_COMMAND:
        if (LOWORD(wp) == ID_SUBMIT_BTN) {
            char at_str[10], bt_str[10], prio_str[10];
            GetWindowText(hAt, at_str, sizeof(at_str));
            GetWindowText(hBt, bt_str, sizeof(bt_str));
            GetWindowText(hPrio, prio_str, sizeof(prio_str));

            int at = atoi(at_str);
            int bt = atoi(bt_str);
            int prio = atoi(prio_str);
            if(at<0&&bt<0&&prio<0){
                                MessageBox(hwnd, "Invalid process details!", "Error", MB_OK);

            }
            if (process_count < 10) {
                p[process_count].pid = process_count + 1;
                p[process_count].at = at;
                p[process_count].bt = bt;
                p[process_count].prio = prio;
                process_count++;

                MessageBox(hwnd, "Process Added!", "Success", MB_OK);
                show_process_table(hwnd);
            } else if(process_count>10){
                MessageBox(hwnd, "Maximum processes reached!", "Error", MB_OK);
            }
           
        } else if (LOWORD(wp) == ID_CALCULATE_BTN) {
            sort_processes(process_count, p);
            execute_processes(hwnd, process_count, p);
            draw_gantt_chart(hwnd, process_count, p);
            update_metrics(hwnd, process_count, p);  // Update metrics in the UI
        } else if (LOWORD(wp) == ID_DELETE_BTN) {
            char pid_str[10];
            GetWindowText(hPidDelete, pid_str, sizeof(pid_str));
            int pid = atoi(pid_str);
            delete_process(hwnd, pid);
            show_process_table(hwnd);
            draw_gantt_chart(hwnd, process_count, p);
            update_metrics(hwnd, process_count, p);  // Update metrics after deletion
        }
        break;

    case WM_DESTROY:
        PostQuitMessage(0);
        break;

    default:
        return DefWindowProc(hwnd, msg, wp, lp);
    }

    return 0;
}

// Function to update metrics in the UI
void update_metrics(HWND hwnd, int n, Process p[n]) {
    char buffer[256];
    int total_wt = 0, total_tat = 0, total_bt = 0;
    float cpu_utilization = 0, throughput = 0;
    
    for (int i = 0; i < n; i++) {
        total_wt += p[i].wt;
        total_tat += p[i].tat;
        total_bt += p[i].bt; // Accumulate burst time for all processes
    }

    float avg_wt = total_wt / (float)n;
    float avg_tat = total_tat / (float)n;
    throughput = n / (float)max_time;
    cpu_utilization = ((float)total_bt / max_time) * 100; // Corrected CPU utilization formula

    sprintf(buffer, "Completion Time: %d", p[n - 1].ft);
    SetWindowText(hCompletionTime, buffer);

    sprintf(buffer, "Turnaround Time: %d", total_tat);
    SetWindowText(hTurnaroundTime, buffer);

    sprintf(buffer, "Waiting Time: %d", total_wt);
    SetWindowText(hWaitingTime, buffer);

    sprintf(buffer, "Response Time: %d", total_wt); // Assuming waiting time as response time
    SetWindowText(hResponseTime, buffer);

    sprintf(buffer, "Throughput: %.2f", throughput);
    SetWindowText(hThroughput, buffer);

    sprintf(buffer, "Average Waiting Time: %.2f", avg_wt);
    SetWindowText(hAvgWaitingTime, buffer);

    sprintf(buffer, "Average Turnaround Time: %.2f", avg_tat);
    SetWindowText(hAvgTurnaroundTime, buffer);

    sprintf(buffer, "Average Response Time: %.2f", avg_wt); // Assuming avg waiting time as avg response time
    SetWindowText(hAvgResponseTime, buffer);

    sprintf(buffer, "CPU Utilization: %.2f%%", cpu_utilization); // Corrected CPU utilization
    SetWindowText(hCPUUtilization, buffer);

    sprintf(buffer, "Fairness: %.2f", (float)total_tat / total_wt);  // Fairness based on TAT/WT
    SetWindowText(hFairness, buffer);
}

// Sort processes by arrival time and priority
void sort_processes(int n, Process p[n]) {
    for (int i = 0; i < n - 1; i++) {
        for (int j = 0; j < n - 1 - i; j++) {
            if (p[j].at > p[j + 1].at || (p[j].at == p[j + 1].at && p[j].prio > p[j + 1].prio)) {
                Process temp = p[j];
                p[j] = p[j + 1];
                p[j + 1] = temp;
            }
        }
    }
}

// Execute processes and update results
void execute_processes(HWND hwnd, int n, Process p[n]) {
    int t = 0; // Current time
    max_time = 0; // Reset max_time before calculating

    for (int i = 0; i < n; i++) {
        if (p[i].at > t) t = p[i].at;
        p[i].ft = t + p[i].bt;
        p[i].tat = p[i].ft - p[i].at;
        p[i].wt = p[i].tat - p[i].bt;
        if (p[i].ft > max_time) max_time = p[i].ft;
        t = p[i].ft;
    }
}

// Display the process table
void show_process_table(HWND hwnd) {
    char buffer[1024];
    strcpy(buffer, "PID\tAT\tBT\tPriority\n");
    for (int i = 0; i < process_count; i++) {
        char line[128];
        sprintf(line, "%d\t%d\t%d\t%d\n", p[i].pid, p[i].at, p[i].bt, p[i].prio);
        strcat(buffer, line);
    }
    MessageBox(hwnd, buffer, "Process Table", MB_OK);
}

// Delete a process by PID
void delete_process(HWND hwnd, int pid) {
    int found = 0;
    for (int i = 0; i < process_count; i++) {
        if (p[i].pid == pid) {
            found = 1;
            for (int j = i; j < process_count - 1; j++) {
                p[j] = p[j + 1];
            }
            process_count--;
            break;
        }
    }
    MessageBox(hwnd, found ? "Process Deleted!" : "Process not found!", "Result", MB_OK);
}

// Draw the Gantt chart
void draw_gantt_chart(HWND hwnd, int n, Process p[n]) {
    if (n == 0) return;

    HDC hdc = GetDC(hwnd);
    int chart_width = 600;
    int chart_height = 50;
    int x_offset = 50;
    int y_offset = 300;

    int start_time = p[0].at;
    for (int i = 1; i < n; i++) {
        if (p[i].at < start_time) start_time = p[i].at;
    }

    RECT clear_rect = {x_offset, y_offset, x_offset + chart_width, y_offset + chart_height + 50};
    FillRect(hdc, &clear_rect, (HBRUSH)(COLOR_WINDOW + 1));

    int time_span = max_time - start_time;
    int unit_width = (time_span > 0) ? chart_width / time_span : chart_width;

    HFONT hFont = CreateFont(16, 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE, 
                             ANSI_CHARSET, OUT_DEFAULT_PRECIS, 
                             CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, 
                             DEFAULT_PITCH | FF_SWISS, "Arial");
    HFONT oldFont = SelectObject(hdc, hFont);

    int current_time = start_time;

    for (int i = 0; i < n; i++) {
        if (p[i].at > current_time) {
            int idle_start = x_offset + (current_time - start_time) * unit_width;
            int idle_end = x_offset + (p[i].at - start_time) * unit_width;
            Rectangle(hdc, idle_start, y_offset, idle_end, y_offset + chart_height);

            // Display idle start time
            char idle_start_label[10];
            sprintf(idle_start_label, "%d", current_time);
            TextOut(hdc, idle_start - 10, y_offset + chart_height + 10, idle_start_label, strlen(idle_start_label));

            current_time = p[i].at;
        }

        int rect_start = x_offset + (current_time - start_time) * unit_width;
        int rect_end = x_offset + (p[i].ft - start_time) * unit_width;

        Rectangle(hdc, rect_start, y_offset, rect_end, y_offset + chart_height);

        char label[10];
        sprintf(label, "P%d", p[i].pid);
        TextOut(hdc, rect_start + (rect_end - rect_start) / 4, y_offset + chart_height / 4, label, strlen(label));

        char time_label[10];
        sprintf(time_label, "%d", p[i].ft);
        TextOut(hdc, rect_end - 10, y_offset + chart_height + 10, time_label, strlen(time_label));

        current_time = p[i].ft;
    }

    char start_time_label[10];
    sprintf(start_time_label, "%d", start_time);
    TextOut(hdc, x_offset - 10, y_offset + chart_height + 10, start_time_label, strlen(start_time_label));

    TextOut(hdc, x_offset, y_offset + chart_height + 30, "Time", 4);

    SelectObject(hdc, oldFont);
    DeleteObject(hFont);
    ReleaseDC(hwnd, hdc);
}